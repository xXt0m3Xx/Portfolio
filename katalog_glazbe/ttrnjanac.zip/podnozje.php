
<body>
    <img src="2.png" alt="" id="pozadina">
</body>

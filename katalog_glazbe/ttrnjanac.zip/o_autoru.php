<?php
include("zaglavlje.php");
$spoji=spajanjeNaBazu();
?>
<!DOCTYPE html>
<html >
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>O autoru</title>
    <link href="stil.css" rel="stylesheet" type="text/css">
</head>
<body>
    <h1>O autoru</h1>
    <ul>
        <li>Tome Trnjanac</li>
        <li>0016145279</li>
        <li>ttrnjanac@foi.hr</li>
        <li>Foi Varaždin</li>
        <li>2022</li>
    </ul>
    <img src="tome.JPG" alt="" width="300" height="400">
</body>
</html>